package com.apps.fullandroidcourseclassc.ui.fragments

import androidx.fragment.app.Fragment
import com.apps.fullandroidcourseclassc.R

class ArchiveFragment :Fragment(R.layout.fragment_archive){
}