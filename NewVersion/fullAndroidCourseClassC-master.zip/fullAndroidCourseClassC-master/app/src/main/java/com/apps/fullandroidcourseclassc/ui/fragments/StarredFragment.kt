package com.apps.fullandroidcourseclassc.ui.fragments

import androidx.fragment.app.Fragment
import com.apps.fullandroidcourseclassc.R

class StarredFragment :Fragment(R.layout.fragment_starred){
}