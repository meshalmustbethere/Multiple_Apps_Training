package com.apps.fullandroidcourseclassc.todolistapp.model

data class Todo(val title:String , var isChecked:Boolean) {}