package com.apps.fullandroidcourseclassc.ui.fragments

import androidx.fragment.app.Fragment
import com.apps.fullandroidcourseclassc.R

class SendFragment :Fragment(R.layout.fragment_send){
}